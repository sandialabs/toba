==== LICENSING

See Toba_license.txt for the license to Toba.
See Samosir_license.txt for the license to Samosir.

Toba is linked to and distributed with the following libraries.  The licenses for those libraries are included in this distribution package.

Lucene (lucene-core-2.0.0.jar) (LUCENE_LICENSE.txt)
HSQLdb (hsqldb.jar) (HSQLDB_LICENSE.txt)
JYTHON (jython.jar) (JYTHON_LICENSE.txt)

==== To Run the software under Windows

Toba does not yet have a simple install package.  Unzip the zip file with the jars into a single directory and execute the following from the command line (or script or batch file):

java -cp BusinessOppPlugin.jar;JepPlugin.jar;toba.jar;WNotePlugin.jar;jythonplugin.jar;samosir.jar;JASEPlugin.jar;jep-2.4.0.jar;jython.jar;hsqldb.jar;jhall.jar;lucene-core-2.0.0.jar org.smalldataproblem.toba.apps.tobaapp.toba - .

Replace the "." with the directory where you want your data files to be stored.

go.bat added for those running windows.

==== To Run the software under Mac OS X

A Mac package has been created.  Just download it, unzip it, and double click the icon.

==== Plugins

When the applications runs, you'll have to register some of the plugins manually.

Do this by adding the following to the plugins list in Tools/Options

org.smalldataproblem.toba.BusinessOpp.BusinessOppMasterPlugin
org.smalldataproblem.toba.JASE.JASEMasterPlugin
org.smalldataproblem.toba.jep.JepMasterPlugin
org.smalldataproblem.toba.jython.JythonMasterPlugin
org.smalldataproblem.toba.WNote.WNoteMasterPlugin

Then restart the application.